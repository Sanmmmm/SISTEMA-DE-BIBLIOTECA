package Uniensino.Modelo;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class Emprestimo {
    private Livro livroEmprestado;
    private Usuario usuarioEmprestimo;
    private LocalDateTime dataEmprestimo;
    private LocalDateTime dataPrevistaDevolucao;
    private LocalDateTime dataDevolucao;

    public Emprestimo(Livro livroEmprestado, Usuario usuarioEmprestimo, LocalDateTime dataEmprestimo, LocalDateTime dataPrevistaDevolucao) {
        this.livroEmprestado = livroEmprestado;
        this.usuarioEmprestimo = usuarioEmprestimo;
        this.dataEmprestimo = dataEmprestimo;
        this.dataPrevistaDevolucao = dataPrevistaDevolucao;
    }

    public Livro getLivroEmprestado() {
        return livroEmprestado;
    }

    public Usuario getUsuarioEmprestimo() {
        return usuarioEmprestimo;
    }

    public LocalDateTime getDataEmprestimo() {
        return dataEmprestimo;
    }

    public LocalDateTime getDataPrevistaDevolucao() {
        return dataPrevistaDevolucao;
    }

    public LocalDateTime getDataDevolucao() {
        return dataDevolucao;
    }

    public void setDataDevolucao(LocalDateTime dataDevolucao) {
        this.dataDevolucao = dataDevolucao;
    }

    public long calcularDiasAtraso() {
        if (dataDevolucao == null) {
            return 0;
        }
        return ChronoUnit.DAYS.between(dataPrevistaDevolucao, dataDevolucao);
    }

    public double calcularMultaPorAtraso() {
        long diasAtraso = calcularDiasAtraso();
        if (diasAtraso <= 0) {
            return 0;
        }
        // Exemplo de cálculo de multa: R$ 1,00 por dia de atraso
        return diasAtraso * 1.0;
    }

    @Override
    public String toString() {
        return "Emprestimo{" +
                "livroEmprestado=" + livroEmprestado.getTitulo() +
                ", usuarioEmprestimo=" + usuarioEmprestimo.getNome() +
                ", dataEmprestimo=" + formatarData(dataEmprestimo) +
                ", dataPrevistaDevolucao=" + formatarData(dataPrevistaDevolucao) +
                ", dataDevolucao=" + (dataDevolucao != null ? formatarData(dataDevolucao) : "Em aberto") +
                '}';
    }

    public String formatarData(LocalDateTime data) {
        if (data == null) {
            return "null";
        }
        return data.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
    }
}
