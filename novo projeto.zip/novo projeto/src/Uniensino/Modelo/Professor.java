package Uniensino.Modelo;

public class Professor extends Usuario {
    private String especialidade;

    public Professor(String nome, int cpf, String genero, String especialidade) {
        super(nome, cpf, genero, "Professor");
        this.especialidade = especialidade;
    }

    public String getEspecialidade() {
        return especialidade;
    }

    public void setEspecialidade(String especialidade) {
        this.especialidade= especialidade;
    }
    @Override
    public String toString() {
        return "Professor{" +
                "nome='" + nome + '\'' +
                ", cpf=" + cpf +
                ", genero='" + genero + '\'' +
                ", tipoUsuario='" + tipoUsuario + '\'' +
                ", Especialidade='" + especialidade + '\'' +
                '}';
    }

    // Métodos específicos de Professor, se necessário
}
