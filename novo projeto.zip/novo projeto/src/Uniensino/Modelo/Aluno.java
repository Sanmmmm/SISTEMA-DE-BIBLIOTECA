package Uniensino.Modelo;

public class Aluno extends Usuario {
    private String matricula;

    public Aluno(String nome, int cpf, String genero, String matricula) {
        super(nome, cpf, genero, "Aluno");
        this.matricula = matricula;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    @Override
    public String toString() {
        return "Aluno{" +
                "nome='" + nome + '\'' +
                ", cpf=" + cpf +
                ", genero='" + genero + '\'' +
                ", tipoUsuario='" + tipoUsuario + '\'' +
                ", matricula='" + matricula + '\'' +
                '}';
    }
}
