package Uniensino.Modelo;

public class Usuario extends Pessoa {
    String tipoUsuario;

    public Usuario(String nome, int cpf, String genero, String tipoUsuario) {
        super(nome, cpf, genero);
        this.tipoUsuario = tipoUsuario;
    }

    public String getTipoUsuario() {
        return tipoUsuario;
    }

    public void setTipoUsuario(String tipoUsuario) {
        this.tipoUsuario = tipoUsuario;
    }


    @Override
    public String toString() {
        return super.toString() +
                ", tipoUsuario='" + tipoUsuario + '\'' +
                '}';
    }


}
