package Uniensino.Modelo;

public abstract class Pessoa {
    protected String nome;
    protected int cpf;
    protected String genero;

    public Pessoa(String nome, int cpf, String genero) {
        this.nome = nome;
        this.cpf = cpf;
        this.genero = genero;
    }
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCpf() {
        return cpf;
    }

    public void setCpf(int cpf) {
        this.cpf = cpf;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    @Override
    public String toString() {
        return "Pessoa{" +
                "nome='" + nome + '\'' +
                ", cpf=" + cpf +
                ", genero='" + genero + '\'' +
                '}';
    }
}
