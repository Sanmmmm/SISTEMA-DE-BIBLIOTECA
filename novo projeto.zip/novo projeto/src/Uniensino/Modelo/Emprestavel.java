package Uniensino.Modelo;
public interface Emprestavel {
    void emprestarLivro();

    void devolverLivro();
}
